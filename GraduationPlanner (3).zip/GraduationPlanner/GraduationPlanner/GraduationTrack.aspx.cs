﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace GraduationPlanner
{
    public partial class GraduationTrack : System.Web.UI.Page
    {
        String connectionString = @"Server=localhost;Database=graduation_planner;Uid=root;Pwd=1234;";
        protected void Page_Load(object sender, EventArgs e)
        {
            using (MySqlConnection sqlCon = new MySqlConnection)
            {
                sqlCon.Open();
                MySqlCommand display = sqlCon.CreateCommand();
                display.CommandType = CommandType.Text;
                display.CommandText = "select username from users where username = " + userUsername;
                MySqlDataReader dr = display.ExecuteReader();
                dr.Read();

                Label2.Text = userUsername;
            }
        }
    }
}