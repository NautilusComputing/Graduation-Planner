﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace GraduationPlanner
{
    public partial class AccountInformation : System.Web.UI.Page
    {
        String connectionString = @"Server=localhost;Database=graduation_planner;Uid=root;Pwd=1234;";
        protected void Page_Load(object sender, EventArgs e)
        {
            using (MySqlConnection sqlCon = new MySqlConnection)
            {
                sqlCon.Open();
                MySqlCommand display = sqlCon.CreateCommand();
                display.CommandType = CommandType.Text;
                display.CommandText = "select username and major from users;
                MySqlDataReader dr = display.ExecuteReader();
                dr.Read();

                username.Text = ;
                major.Text = ;
            }
        }
        protected void backButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("GraduationTrack.aspx");
        }
    }
}