﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GraduationPlanner
{
    public partial class GPACalculator : System.Web.UI.Page
    {
        String letterGrade;
        double credits = 0;
        double calTimes = 0;
        double totalCal = 0;
        double totalCredits = 0;
        double finalGPA = 0;
        double A = 4.0;
        double B = 3.0;
        double C = 2.0;
        double D = 1.0;
        double F = 0.0;
        DropDownList letterCombo = new DropDownList();
        DropDownList creditCombo = new DropDownList();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void calculateGPA_Click(object sender, EventArgs e)
        {
            letterGrade = "";
            credits = 0;
            calTimes = 0;
            totalCal = 0;
            totalCredits = 0;
            finalGPA = 0;
            letterCombo = new DropDownList();
            creditCombo = new DropDownList();

            for (int i = 0; i < 4; i++)
            {
                switch (i)
                {
                    case 0:
                        letterCombo = Class1Grade;
                        creditCombo = Class1CreditHours;
                        break;

                    case 1:
                        letterCombo = Class2Grade;
                        creditCombo = Class2CreditHours;
                        break;
                    case 2:
                        letterCombo = Class3Grade;
                        creditCombo = Class3CreditHours;
                        break;
                    case 3:
                        letterCombo = Class4Grade;
                        creditCombo = Class4CreditHours;
                        break;
                }
                letterGrade = letterCombo.Text;
                credits = Convert.ToDouble(creditCombo.Text);

                if (letterGrade != String.Empty && creditCombo != 0)
                {
                    switch (letterGrade)
                    {
                        case "A":
                            calTimes = credits * A;
                            break;
                        case "B":
                            calTimes = credits * B;
                            break;
                        case "C":
                            calTimes = credits * C;
                            break;
                        case "D":
                            calTimes = credits * D;
                            break;
                        case "F":
                            calTimes = credits * F;
                            break;
                        case "NA":
                            calTimes = 0;
                            break;
                    }

                    totalCredits = totalCredits + credits;
                    totalCal = totalCal + calTimes;
                }
            }
            finalGPA = totalCal / totalCredits;
            ProjectedGPA.Text = finalGPA.ToString();
        }
    }
}