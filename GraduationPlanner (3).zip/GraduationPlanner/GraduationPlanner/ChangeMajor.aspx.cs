﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GraduationPlanner
{
    public partial class ChangeMajor : System.Web.UI.Page
    {
        String connectionString = @"Server=localhost;Database=graduation_planner;Uid=root;Pwd=1234;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void confirm_Click(object sender, EventArgs e)
        {

        }
    }
}