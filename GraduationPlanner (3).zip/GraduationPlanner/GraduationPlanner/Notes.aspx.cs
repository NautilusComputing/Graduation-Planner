﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace GraduationPlanner
{
    public partial class Notes : System.Web.UI.Page
    {
        String connectionString = @"Server=localhost;Database=graduation_planner;Uid=root;Pwd=1234;";
        string notes;
        protected void Page_Load(object sender, EventArgs e)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open();
                MySqlCommand display = sqlCon.CreateCommand();
                display.CommandType = CommandType.Text;
                display.CommandText = "select notes from users";
                MySqlDataReader dr = display.ExecuteReader();
                dr.Read();

                MySqlDataAdapter da = new MySqlDataAdapter(display);
                DataSet ds = new DataSet();
                da.Fill(ds);
                NotesList.DataTextField = ds.Tables[0].Columns["Notes"].ToString();
                NotesList.DataSource = ds.Tables[0];
                NotesList.DataBind();
            }
        }

        protected void displayButton_Click(object sender, EventArgs e)
        {
            notes = NotesList.Selected();
            NoteLabel.Text = notes;
        }
    }
}