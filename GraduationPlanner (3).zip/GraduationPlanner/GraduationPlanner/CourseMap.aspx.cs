﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace GraduationPlanner
{
    public partial class CourseMap : System.Web.UI.Page
    {
        String connectionString = @"Server=localhost;Database=graduation_planner;Uid=root;Pwd=1234;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}