﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Mime;

namespace Assign_4
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            password.Attributes["type"] = "password";
            confirmPassword.Attributes["type"] = "password";
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            string firstname = "\'" + fname.Text + "\'";
            string lastname = "\'" + lname.Text + "\'";
            string userID = "\'" + username.Text + "\'";
            string pass = "\'" + password.Text + "\'";
            string confirmPass = "\'" + confirmPassword.Text + "\'";
            string emailAddress = "\'" + email.Text + "\'";
            string secQ = "\'" + securityQuestion.Text + "\'";
            string secA = "\'" + securityAnswer.Text + "\'";

            string connnStr = "Server=seths.database.windows.net;Database=assign4;User Id=seth; Password=HelloNewman!@#;";//Change to ISU SQL server
            SqlConnection conn = new SqlConnection(connnStr);
            conn.Open();

            SqlCommand cmd = new SqlCommand();

            if(pass != confirmPass)
            {
                confirmationMessage.Text = "Passwords do not match, please make sure that they are the same.";
            }
            else if(connnStr.Contains(userID))
            {
                confirmationMessage.Text = "Username already exists, please choose another username.";
            }
            else
            {
                
                cmd.Parameters.Add("@firstName", firstname);
                cmd.Parameters.Add("@lastname", lastname);
                cmd.Parameters.Add("@username", userID);
                cmd.Parameters.Add("@password", pass);
                cmd.Parameters.Add("@email", emailAddress);
                cmd.Parameters.Add("@securityQuestion", secQ);
                cmd.Parameters.Add("@securityAnswer", secA);

                sendEmail(email.Text);

                confirmationMessage.Text = "User information Accepted, confirmation email sent.";
            }
            conn.Close();
        }

        protected void sendEmail(string emailAdd)
        {
            //MailAddress messageFrom = new MailAddress(email);
            //MailAddress emailMessage = new MailAddress();
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(emailAdd);
            mail.From = new MailAddress("sdtealb@ilstu.edu", "No-Reply", System.Text.Encoding.UTF8);
            mail.Subject = "Account Confirmation";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            mail.Body = "Congratulations on making an account, here is what we have gathered.\n\n" + "First Name: " + fname.Text + "\n"
                + "Last Name: " + lname.Text + "\n"
                + "Username: " + username.Text + "\n"
                + "Password: " + password.Text + "\n"
                + "Email: " + email.Text + "\n"
                + "Security Question: " + securityQuestion.Text + "\n"
                + "Security Answer: " + securityAnswer.Text + "\n\n"
                + "Thank you for registering, and have a great day!";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("sdtealb@ilstu.edu", "ISpeakinL33T!");
            client.Port = 587;
            client.Host = "smtp.office365.com";
            client.EnableSsl = true;
            client.Send(mail);
        }

        //private AlternateView Mail_Body()
        //{

        //}
    }
}