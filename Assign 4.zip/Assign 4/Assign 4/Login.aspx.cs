﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign_4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string username = string.Empty;
        string password = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox2.Attributes["type"] = "password";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string userID = "\'" + TextBox1.Text + "\'";
            string passID = "\'" + TextBox2.Text + "\'";

            string connnStr = "Server=seths.database.windows.net;Database=assign4;User Id=seth; Password=HelloNewman!@#;";//Change to ISU SQL server
            SqlConnection conn = new SqlConnection(connnStr);
            conn.Open();



            SqlCommand cmd = new SqlCommand("SELECT [loginID],[loginPSWD] FROM [dbo].[Login_Info] WHERE [loginID] =" + userID + "and [loginPSWD] =" + passID);
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Connection = conn;

            string tempLogin = "";
            string tempPassword = "";

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                tempLogin = reader["loginID"].ToString();
                tempPassword = reader["loginPSWD"].ToString();
            }

            //TextBox1.Text = tempLogin;
            //TextBox2.Text = tempPassword;

            if(TextBox1.Text == tempLogin && TextBox2.Text == tempPassword)
            {
                loginMessage.Text = "Login successful, hello " + tempLogin;
            }
            else
            {
                loginMessage.Text = "Login failed, username and/or password are incorrect.";
            }

            conn.Close();
        }
    }
}