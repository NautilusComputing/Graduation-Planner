﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign_4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Connect to DB
            //string connnStr = "Server=12.0.2000.8;Database=assign4;User Id=seth; Password=HelloNewman!@#;";
            string connnStr = "Server=seths.database.windows.net;Database=assign4;User Id=seth; Password=HelloNewman!@#;";
            SqlConnection conn = new SqlConnection(connnStr);
            conn.Open();

            //Create a command
            SqlCommand cmd = new SqlCommand("SELECT [loginID],[loginPSWD],[loginSecQuest],[loginSecAns] FROM [dbo].[Login_Info]");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Connection = conn;

            string temp = "";

            //Read from database
            SqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read())
            {
                temp += reader["loginID"].ToString();
                temp += reader["loginPSWD"].ToString();
                temp += "<br/>";
            }

            conn.Close();

            lbl_test.Text = temp;
        }
    }
}